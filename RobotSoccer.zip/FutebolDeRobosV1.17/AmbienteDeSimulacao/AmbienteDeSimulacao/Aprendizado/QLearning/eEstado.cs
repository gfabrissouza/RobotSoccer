﻿namespace AmbienteDeSimulacao.Aprendizado.QLearning
{
    public enum eEstado
    {
        Estado_1,
        Estado_2,
        Estado_3,
        Estado_4,
        Estado_5,
    }
}
