﻿namespace AmbienteDeSimulacao.Aprendizado.QLearning
{
    public enum eAcaoGoleiro
    {
        // Ações do goleiro
        Defender,
        Posicionar,
        Reposicao,
    }
}
