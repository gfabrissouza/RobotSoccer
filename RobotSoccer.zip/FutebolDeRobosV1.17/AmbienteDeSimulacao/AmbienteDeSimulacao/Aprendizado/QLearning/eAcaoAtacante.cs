﻿namespace AmbienteDeSimulacao.Aprendizado.QLearning
{
    public enum eAcaoAtacante
    {
        // Ações do atacante
        Chutar,
        Driblar,
        Dominar,
        Desarmar,
        Fintar,        
    }
}
