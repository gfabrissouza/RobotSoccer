﻿namespace AmbienteDeSimulacao.Ambiente.FisicaAmbiente.Corpos
{
    public enum Massa
    {
        massaBola = 1,
        massaAgente = 15
    }
}
