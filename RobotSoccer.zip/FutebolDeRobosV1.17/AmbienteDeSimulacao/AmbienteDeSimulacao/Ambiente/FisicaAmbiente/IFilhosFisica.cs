﻿namespace AmbienteDeSimulacao.Ambiente.FisicaAmbiente
{
    interface IFilhosFisica
    {
        void Atualiza();
    }
}
