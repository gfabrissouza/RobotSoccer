﻿namespace AmbienteDeSimulacao.Ambiente.FisicaAmbiente.Movimento
{
    enum eAmortecimento : long
    {
        amortecimento = (long)0.95
    }
}
