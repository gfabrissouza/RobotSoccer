﻿namespace AmbienteDeSimulacao.Ambiente
{
    public interface IFilhosAmbiente
    {
        void Atualiza();      
    }
}
